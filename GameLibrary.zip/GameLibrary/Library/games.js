// Zentrales Verzeichnis: Ordnernamen aus Games/ (exakte Gross-/Kleinschreibung!)
window.GAME_FOLDERS = [
  "Demo-Klick"
  // , "Jump-n-Run", "WordLock", "Tumbler"
];
