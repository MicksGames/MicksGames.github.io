registerGame({
  title: "Demo Klick",
  description: "Kleines Beispielspiel: Triff die Quadrate, bevor sie verschwinden. Ersetze es durch deine eigenen Spiele.",
  category: "Arcade",
  website: "",
  thumbnail: "thumbnail.png",
  gameFile: "index.html"
});
